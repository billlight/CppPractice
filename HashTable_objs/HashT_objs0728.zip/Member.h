/*
 * Member.h
 *
 *  Created on: 2019��7��24��
 *      Author: yifan
 */

#ifndef MEMBER_H
#define MEMBER_H
#include <string>
using namespace std;

static const string lName [] = {
        "Abdalla", "Andres", "Anzai", "Armstrong", "Arvig", "Ash", "Baca", "Badine",
        "Baehr", "Bair", "Baligad", "Barlow", "Barrett", "Becker", "Bell",
        "Benbow", "Biggs", "Blevins", "Blood", "Bohan", "Bond", "Bonner",
        "Bosch", "Bryson", "Buechele", "Bullis", "Burk", "Burns", "Byron",
        "Calderon", "Careuthers", "Carr", "Carson", "Carter", "Castle", "Chan",
        "Charney", "Christenson", "Cisneros", "Cliton", "Coldewey", "Coodey",
        "Cook", "Cooper", "Coy", "Currie", "Curtis", "Dirkse", "Dirscoll",
        "Dodrill", "Ehlert", "Elias", "Elliott", "Enterline", "Ericsson",
        "Fernandez", "Fisher", "Flory", "Freese", "Fruzza", "Fu", "Fuhrman", "Gage",
        "Garcia", "Garmon", "Giffith", "Gill", "Gillen", "Glascock", "Gomez",
        "Goraya", "Greer", "Hansen", "Hartley", "Hawkins", "Hemme", "Hensley",
        "Hentges", "Herron", "Hightower", "Hines", "Holloway", "Holmes",
        "Issac", "Jackson", "Jagodin", "Jiang", "Johnson", "Jordan", "Jouda", "Joven",
        "Kalpesh", "Katz", "Kaur", "Kegley", "Kimsey", "King", "Kohn", "Kone",
        "LaCasse", "Lackey", "Lathrop", "Le", "Levy", "Lynos", "Maas", "Mackall",
        "Madsen", "Magee", "Maldonado", "McDaneld", "McMillian", "McNeill",
        "Meadors", "Medina", "Metz", "Millikin", "Minner", "Mondragon", "Monge", "Moore",
        "Moreno", "Murkland", "Musick", "Myers", "Neal", "Ngo", "Nolan", "Nunez",
        "O'Neil", "Oropeza", "Owen", "Patel", "Pfister", "Philips", "Picato",
        "Porras", "Porter", "Pratt", "Pryor", "Ragle", "Rai", "Raja", "Rill",
        "Roberts", "Roddy", "Rose", "Roux", "Rubio", "Ruiz", "Saito", "Samidin",
        "Sampson", "Sanchez", "Scanlan", "Schmidt", "Schoberg", "Sheppard",
        "Simmons", "Sison", "Smith", "Snow", "Soto", "Sozinho", "Stevens",
        "Stidham", "Strange", "Sy", "Tamayo", "Taylor", "Thomas", "Tran", "Vincent",
        "Walker", "Wandke", "Ward", "Warner", "Waugh", "Webb", "Wells", "White",
        "Wilson", "Winther", "Wuertz", "Yong" };

static const string fName [] = {
        "Aaron","Alan", "Ali", "Alicia","Andrew", "Anne", "Anthony", "Archie", "Ariel",
        "Arlene", "Barbara", "Bebedict", "Benjamin", "Bey-Fen", "Bikram", "Brain",
        "Brandon", "Brent", "Brian", "Brock", "Candice", "Cathleen", "Chad",
        "Charles", "Charlie", "Christopher", "Cindy", "Clinton", "Craig", "Daniel",
        "Danna", "David", "Dean", "Denise", "Dexter", "Diane", "Dinna", "Donna",
        "Douglas", "Eduardo", "Edward", "Elsa", "Eric", "Ernesto", "Fernando",
        "Francisco", "Frank", "Gabby", "Garmund", "Garvin", "Genevieve", "George",
        "Gil", "Gregory", "Gurinder", "Hemant", "Herman", "Hernando", "Isabel",
        "James", "Janet", "Janice", "Jarret", "Jason", "Javier", "Jeffrey",
        "Jennifer", "Jeremy", "Jerold", "Jerrie", "Jim", "Joanna", "Joe", "Joel", "John",
        "Jon", "Jonathan", "Jose", "Joseph", "Josephine", "Josh", "Joshua",
        "Julie", "Kenneth", "Kenny", "Kent", "Kristi", "Kurt", "Kyle", "Lance",
        "Laura", "Leslie", "Malcolm", "Maneje", "Manja", "Marco", "Marcos",
        "Marcus", "Marianna", "Maritza", "Mark", "Marques", "Masaaki", "Mathew", "Matt",
        "Mayur", "Melissa", "Michael", "Miera", "Mike", "Mina", "Mohamed", "Moises",
        "Morgan", "Muntaga", "Myron", "Nathan", "Nilli", "Norma", "Olga",
        "Paradorn", "Patel", "Patrick", "Paul", "Pedro", "Peter", "Philip",
        "Preet", "Ralf", "Ralph", "Raymond", "Reuben", "Ricardo", "Richard",
        "Robert", "Roberto", "Rohit", "Ronald", "Ronne", "Rosa", "Roy", "Rushabh",
        "Ryan", "Samat", "Sara", "Sarah", "Scott", "Sean", "Sergio", "Shahzad", "Shawn",
        "Shi-Wei", "Silvia", "Simon", "Stacy", "Stephanie", "Stephen", "Steven",
        "Sukhum", "Susan", "Suzanne", "Tahnee", "Tahra", "Tam", "Tammy", "Tate",
        "Terry", "Thomas", "Thonas", "To", "Todd", "Tommy", "Travis", "Trevor",
        "Troy", "Valerie", "Ven", "Victor", "Vidya", "Vikramjwed", "Wernher",
        "Wesley", "William", "Yu" } ;


class Member{
  public:
	int ID;
	string lastName;
	string firstName;
	Member(){
		ID = rand() % 10000;
		int k = rand() % 180;
		lastName = lName[k];
		firstName = fName[k];
	}
	Member(int id, string lName, string fName){
		ID = id;
		lastName = lName;
		firstName = fName;
	}
	friend bool operator < (Member c1, Member c2);
	friend bool operator == (Member c1, Member c2);
	string toString(){
		string infor = lastName + " " + firstName;
		return infor;
	}
};
class Student{
  public:
	int ID;
	string lastName;
	string firstName;
	Student(){
		ID = rand() % 10000;
		int k = rand() % 180;
		lastName = lName[k];
		firstName = fName[k];
	}
	Student(int id, string lName, string fName){
		ID = id;
		lastName = lName;
		firstName = fName;
	}
	//friend bool operator < (Student c1, Student c2);
	//friend bool operator == (Student c1, Student c2);
	string toString(){
		string infor = lastName + " " + firstName;
		return infor;
	}
};

bool operator < (Member c1, Member c2)
{
     return c1.ID < c2.ID;
}
bool operator == (Member c1, Member c2)
{
     return c1.ID == c2.ID;
}



#endif /* MEMBER_H */
